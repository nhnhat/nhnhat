# Text Normalizer - J1_L_P0025

## Mô tả
Chương trình Java đọc file văn bản (input.txt), chuẩn hóa nội dung theo các quy tắc,
rồi ghi kết quả ra file (output.txt).

## Cấu trúc MVC

```
src/
├── Main.java                          ← Entry point
├── controller/
│   └── TextNormalizerController.java  ← Điều phối Model và View
├── model/
│   ├── TextDocument.java              ← Dữ liệu (raw + normalized text)
│   ├── TextNormalizer.java            ← Logic chuẩn hóa văn bản
│   └── FileHandler.java               ← Đọc/ghi file
├── view/
│   └── ConsoleView.java               ← Hiển thị output ra console
└── exception/
    ├── FileReadException.java         ← Lỗi đọc file
    ├── FileWriteException.java        ← Lỗi ghi file
    └── EmptyFileException.java        ← File rỗng
```

## Quy tắc chuẩn hóa

| # | Quy tắc |
|---|---------|
| 1 | Không có dòng trống giữa các dòng (gộp thành 1 đoạn) |
| 2 | Chỉ một khoảng trắng giữa các từ |
| 3 | Chỉ một khoảng trắng sau dấu `,` `.` `:` |
| 4 | Chữ cái đầu của từ sau dấu `.` viết Hoa; các từ còn lại viết thường |
| 5 | Không có khoảng trắng trước/sau nội dung trong dấu ngoặc kép `""` |
| 6 | Chữ cái đầu tiên của văn bản viết Hoa |
| 7 | Không có khoảng trắng giữa dấu `,` `.` và từ đứng trước nó |
| 8 | Văn bản kết thúc bằng dấu `.` |

## Exception Handling

| Exception | Khi nào xảy ra |
|-----------|----------------|
| `FileReadException` | File không tồn tại, không có quyền đọc, lỗi I/O |
| `FileWriteException` | Không có quyền ghi, lỗi I/O khi ghi |
| `EmptyFileException` | File tồn tại nhưng nội dung rỗng |

## Biên dịch và chạy

```bash
# Biên dịch
javac -d out -sourcepath src $(find src -name "*.java")

# Chạy (mặc định dùng input.txt và output.txt)
java -cp out Main

# Chạy với file tùy chỉnh
java -cp out Main myInput.txt myOutput.txt
```

## Ví dụ

**Input (input.txt):**
```
as you can see, detecting whether a string is normalized can be quite efficient. A lot of the cost of normalizing in the "second row" is for the initialization of buffers. The cost of which is amortized when one is processing larger strings.
 As it turns out, these buffers are rarely needed, so we may change the implementation at some point to speed up the common case for small strings even further
```

**Output (output.txt):**
```
As you can see, detecting whether a string is normalized can be quite efficient. A lot of the cost of normalizing in the "second row" is for the initialization of buffers. The cost of which is amortized when one is processing larger strings. As it turns out, these buffers are rarely needed, so we may change the implementation at some point to speed up the common case for small strings even further.
```
